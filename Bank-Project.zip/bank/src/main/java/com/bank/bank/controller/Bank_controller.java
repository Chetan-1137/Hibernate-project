package com.bank.bank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bank.bank.entity.Login;

@Controller
public class Bank_controller {
 @RequestMapping("/")
	public ModelAndView login_page() {
		return new ModelAndView("login");
	}
	@PostMapping("login")
	public ModelAndView login(@ModelAttribute Login login) {
		
		return new ModelAndView("Home");
		
	}
}
 